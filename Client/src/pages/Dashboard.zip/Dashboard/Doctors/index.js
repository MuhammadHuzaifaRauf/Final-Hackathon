import React from 'react'
import Student from './Student'

export default function index() {
  return (
    <Student/>
  )
}
