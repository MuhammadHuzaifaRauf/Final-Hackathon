import React from 'react'
import AddDr from './AddDr'

export default function index() {
  return (
    <AddDr/>
  )
}
