import React from 'react'
import AddCourse from './AddCourse'

export default function index() {
  return (
    <AddCourse/>
  )
}
