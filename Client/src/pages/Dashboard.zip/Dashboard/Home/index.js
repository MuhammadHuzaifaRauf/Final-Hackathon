import React from 'react'
import Home from './Home'

export default function index() {
  return (
    <Home/>
  )
}
