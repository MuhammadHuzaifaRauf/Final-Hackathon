// import React, { PureComponent } from 'react';
import React, { useEffect, useState } from 'react'

import { PieChart, Pie, BarChart, Bar, Rectangle, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, Cell } from 'recharts';
const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042'];

export default function LinChart() {
    
    

    return (
        <>
           
        </>
    );
}

