import React from 'react'
import Course from './Course'

export default function index() {
  return (
    <Course/>
  )
}
